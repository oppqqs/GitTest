﻿module.exports = "<p style='color:blue'>" + require("./message.js") + "</p>";
