﻿const webpack = require('webpack');

module.exports = {
    entry: { js: './server.js' },
    output: { filename: './bundle.js' }
}