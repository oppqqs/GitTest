/// <reference types="mocha" />
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var chai_1 = require("chai");
describe('MyPartWebPart', function () {
    it('should do something', function () {
        chai_1.assert.ok(true);
    });
});
//# sourceMappingURL=MyPart.test.js.map