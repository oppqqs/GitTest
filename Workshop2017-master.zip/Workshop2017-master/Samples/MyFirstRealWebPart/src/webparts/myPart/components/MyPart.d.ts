import * as React from 'react';
import { IMyPartProps } from './IMyPartProps';
export default class MyPart extends React.Component<IMyPartProps, void> {
    render(): React.ReactElement<IMyPartProps>;
}
