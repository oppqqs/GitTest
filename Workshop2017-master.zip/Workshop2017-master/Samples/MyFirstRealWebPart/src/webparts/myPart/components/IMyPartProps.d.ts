export interface IMyPartProps {
    description: string;
}
