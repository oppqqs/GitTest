export interface IMyPartProps {
  message: string;
}

