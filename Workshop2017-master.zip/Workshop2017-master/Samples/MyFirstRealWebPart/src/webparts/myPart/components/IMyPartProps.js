"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=IMyPartProps.js.map