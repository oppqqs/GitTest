export interface IHelloUserWebPartProps {
  description: string;
}
