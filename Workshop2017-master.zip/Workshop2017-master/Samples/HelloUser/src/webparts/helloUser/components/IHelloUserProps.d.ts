export interface IHelloUserPartProps {
    busyMessage: string;
}
export interface IHelloUserPartState {
    data: string;
    isValid: boolean;
}
