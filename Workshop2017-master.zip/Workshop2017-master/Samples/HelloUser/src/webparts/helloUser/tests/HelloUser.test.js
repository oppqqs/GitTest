/// <reference types="mocha" />
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var chai_1 = require("chai");
describe('HelloUserWebPart', function () {
    it('should do something', function () {
        chai_1.assert.ok(true);
    });
});
//# sourceMappingURL=HelloUser.test.js.map