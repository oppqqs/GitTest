/// <reference types="mocha" />

import { assert } from 'chai';

describe('HelloUserWebPart', () => {
  it('should do something', () => {
    assert.ok(true);
  });
});
