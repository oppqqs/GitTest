"use strict";
/// <reference types="mocha" />
Object.defineProperty(exports, "__esModule", { value: true });
const chai_1 = require("chai");
describe('FavoritePollWebPart', () => {
    it('should do something', () => {
        chai_1.assert.ok(true);
    });
});
//# sourceMappingURL=FavoritePoll.test.js.map