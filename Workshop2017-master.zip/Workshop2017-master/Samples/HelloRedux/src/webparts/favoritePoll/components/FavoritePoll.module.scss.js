"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/* tslint:disable */
require('./FavoritePoll.module.css');
const styles = {
    favoritePoll: 'favoritePoll_a70c9a76',
    container: 'container_a70c9a76',
    row: 'row_a70c9a76',
    listItem: 'listItem_a70c9a76',
    button: 'button_a70c9a76',
    label: 'label_a70c9a76',
};
exports.default = styles;
/* tslint:enable */ 
//# sourceMappingURL=FavoritePoll.module.scss.js.map