import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';
export default class FavoritePollWebPart extends BaseClientSideWebPart<null> {
    private store;
    constructor();
    public render(): void;
}
