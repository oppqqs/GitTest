declare interface IFavoritePollStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'favoritePollStrings' {
  const strings: IFavoritePollStrings;
  export = strings;
}
