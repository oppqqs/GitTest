"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var React = require("react");
var ReactDOM = require("react-dom");
var app_component_1 = require("./app.component");
ReactDOM.render(React.createElement(app_component_1.MyComponent, { message: "Properties don't change!" }), document.getElementById('container'));
//# sourceMappingURL=boot.js.map