"use strict";
var AppModel = (function () {
    function AppModel(message) {
        this.message = message;
    }
    return AppModel;
}());
exports.AppModel = AppModel;
//# sourceMappingURL=app.model.js.map