define([], function() {
  return {
    "Title": "PercentCustomizerFieldCustomizer"
  }
});