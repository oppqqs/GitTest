declare interface IPercentCustomizerFieldCustomizerStrings {
  Title: string;
}

declare module 'PercentCustomizerFieldCustomizerStrings' {
  const strings: IPercentCustomizerFieldCustomizerStrings;
  export = strings;
}
