"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/* tslint:disable */
require('./AppCustomizer.module.css');
var styles = {
    app: 'app_e0aec02a',
    top: 'top_e0aec02a',
    bottom: 'bottom_e0aec02a',
};
exports.default = styles;
/* tslint:enable */ 
//# sourceMappingURL=AppCustomizer.module.scss.js.map