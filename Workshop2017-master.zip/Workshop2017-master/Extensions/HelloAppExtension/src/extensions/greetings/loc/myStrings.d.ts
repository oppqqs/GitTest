declare interface IGreetingsApplicationCustomizerStrings {
  Title: string;
}

declare module 'GreetingsApplicationCustomizerStrings' {
  const strings: IGreetingsApplicationCustomizerStrings;
  export = strings;
}
