define([], function() {
  return {
    "Title": "Header and Footer Extension"
  }
});