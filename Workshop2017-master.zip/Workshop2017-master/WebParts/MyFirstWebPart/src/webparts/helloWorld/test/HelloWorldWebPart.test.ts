/// <reference types="mocha" />

import { assert } from 'chai';

describe('HelloWorldWebPart', () => {
  it('should do something', () => {
    assert.ok(true);
  });
});
