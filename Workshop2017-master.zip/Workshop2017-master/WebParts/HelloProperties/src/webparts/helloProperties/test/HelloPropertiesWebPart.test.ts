/// <reference types="mocha" />

import { assert } from 'chai';

describe('HelloPropertiesWebPart', () => {
  it('should do something', () => {
    assert.ok(true);
  });
});
