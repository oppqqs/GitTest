define([], function () {
  return {
      PropertyPaneDescription: "Properties!",
      BasicGroupName: "Basic Properties",
      AdvancedGroupName: "Advanced Properties",
      TextFieldLabel: "Single-line text",
      CheckboxFieldLabel: "Simple checkbox",
      LabelFieldLabel: "Simple read-only label",
      LinkFieldText: "A link to the Microsoft site",
      LinkFieldUrl: "http://www.microsoft.com",
      SliderFieldLabel: "A slider control",
      ToggleFieldLabel: "A toggle control",
      DropdownFieldLabel: "Drop-down list"
  }
});